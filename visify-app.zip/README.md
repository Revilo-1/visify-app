# Visify - Review Management Platform

En platform til at håndtere kundeanmeldelser på tværs af forskellige platforme.

## Funktioner

- Brugerautentificering med roller (admin/bruger)
- Admin-panel til brugeradministration
- Anmod om anmeldelser fra kunder
- Analytics og statistikker
- Flersproget understøttelse (dansk/engelsk)

## Kom i gang

1. Klon dette repository
2. Installer afhængigheder:
   ```
   npm install
   ```
3. Start udviklingsserveren:
   ```
   npm start
   ```
4. Åbn http://localhost:3000 i din browser

## Login-oplysninger

**Admin-bruger:**
- E-mail: admin@example.com
- Adgangskode: admin123

**Standard bruger:**
- E-mail: user@example.com
- Adgangskode: user123

## Deployment

Applikationen er klar til at blive hostet på enhver statisk webhosting-tjeneste som Netlify, Vercel, GitHub Pages, etc.

## Licens

Dette projekt er lukket kildekode.
